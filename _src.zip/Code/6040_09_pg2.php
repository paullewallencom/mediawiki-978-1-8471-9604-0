#Grant sysop access to MaintenanceShell
$wgGroupPermissions[�sysop�][�maintenanceshell�] = true

#MaintenanceShell extension
Require_once(�$IP/extensions/MaintenanceShell/MaintenanceShell.php�);

