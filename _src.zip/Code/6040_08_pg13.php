//Bad Behavior
include_once( 'includes/DatabaseFunctions.php' );
include( './extensions/bad-behavior/bad-behavior-mediawiki.php' );
