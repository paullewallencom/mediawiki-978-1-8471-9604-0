$wgNamespacesWithSubpages = array(   
	NS_TALK           => true,
	NS_USER           => true,
	NS_USER_TALK      => true,
	NS_PROJECT_TALK   => true,
	NS_FILE_TALK      => true,
	NS_MEDIAWIKI_TALK => true,
	NS_TEMPLATE_TALK  => true,
	NS_HELP_TALK      => true,
	NS_CATEGORY_TALK  => true,
	TUTORIALS	        => true,
	TUTORIALS_TALK	 => true
);

$wgNamespacesToBeSearchedDefault = array(  
	NS_MAIN           => true,
	TUTORIALS	  => true
);
