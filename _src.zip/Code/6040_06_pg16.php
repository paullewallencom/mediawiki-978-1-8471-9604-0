#Add other file extensions to upload
$wgFileExtensions = array('png','jpg','jpeg','ogg','doc','xls','ppt','mp3','pdf')

#Ogg handler extension
require( "$IP/extensions/OggHandler/OggHandler.php" );
